<?php
require_once __DIR__.'/retencaoBootstrap.php';
executarRetencao(static function(PDO $conn,array $input): array {
    $token=(string)($input['token'] ?? '');
    if(!preg_match('/^[a-f0-9]{64}$/D',$token))throw new InvalidArgumentException('Token inválido.');
    $s=$conn->prepare("SELECT expira_em FROM reservas_temporarias WHERE token=? AND status='pendente' AND expira_em>?");$s->execute([$token,date('Y-m-d H:i:s')]);$expiry=$s->fetchColumn();
    if(!$expiry)throw new InvalidArgumentException('O tempo para pagar expirou. Volte ao checkout e reserve as vagas novamente.');
    return ['success'=>true,'segundos_restantes'=>max(0,strtotime($expiry)-time())];
});
