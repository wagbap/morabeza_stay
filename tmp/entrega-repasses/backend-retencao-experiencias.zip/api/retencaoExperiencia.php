<?php
declare(strict_types=1);

function sincronizarPendentesSessao(PDO $conn, int $sessaoId): void {
    $stmt = $conn->prepare("SELECT COALESCE(SUM(quantidade),0) FROM reservas_temporarias WHERE sessao_id=? AND status='pendente'");
    $stmt->execute([$sessaoId]);
    $total = (int)$stmt->fetchColumn();
    $stmt = $conn->prepare('UPDATE experiencia_sessoes SET reservas_pendentes=? WHERE id=?');
    $stmt->execute([$total, $sessaoId]);
}

function reservarVagasTemporarias(PDO $conn, array $input): array {
    $sid = filter_var($input['sessao_id'] ?? null, FILTER_VALIDATE_INT, ['options'=>['min_range'=>1]]);
    $qtd = filter_var($input['quantidade'] ?? null, FILTER_VALIDATE_INT, ['options'=>['min_range'=>1]]);
    if (!$sid || !$qtd) throw new InvalidArgumentException('sessao_id e quantidade devem ser inteiros positivos.');
    $uid = !empty($input['usuario_id']) ? filter_var($input['usuario_id'], FILTER_VALIDATE_INT, ['options'=>['min_range'=>1]]) : null;
    if ($uid === false) throw new InvalidArgumentException('Utilizador inválido.');
    $modelo = $input['modelo'] ?? 'por_pessoa';
    if (!in_array($modelo, ['por_pessoa','grupo_privado'], true)) throw new InvalidArgumentException('Modelo inválido.');
    $now = date('Y-m-d H:i:s');
    $expires = date('Y-m-d H:i:s', time() + 300);
    $conn->beginTransaction();
    try {
        // All reservation and release operations lock the session first.
        $stmt = $conn->prepare('SELECT * FROM experiencia_sessoes WHERE id=? FOR UPDATE');
        $stmt->execute([$sid]); $sessao = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$sessao || empty($sessao['ativo'])) throw new InvalidArgumentException('Sessão não encontrada ou inativa.');
        if (!empty($input['experiencia_id']) && (int)$input['experiencia_id'] !== (int)$sessao['experiencia_id']) throw new InvalidArgumentException('Esta sessão não pertence à experiência.');
        $stmt = $conn->prepare("UPDATE reservas_temporarias SET status='expirada' WHERE sessao_id=? AND status='pendente' AND expira_em<=?");
        $stmt->execute([$sid,$now]);
        $stmt = $conn->prepare("SELECT * FROM reservas_temporarias WHERE sessao_id=? AND status='pendente' ORDER BY id DESC FOR UPDATE");
        $stmt->execute([$sid]); $holds = $stmt->fetchAll(PDO::FETCH_ASSOC);
        $own = []; $other = 0;
        $tokenInput = is_string($input['token'] ?? null) ? $input['token'] : '';
        foreach ($holds as $hold) {
            if (($uid && (int)$hold['usuario_id'] === $uid) || ($tokenInput !== '' && hash_equals((string)$hold['token'], $tokenInput))) $own[] = $hold;
            else $other += (int)$hold['quantidade'];
        }
        // The customer's own existing hold is credited BEFORE checking stock.
        $available = max(0, (int)$sessao['capacidade_maxima'] - (int)$sessao['vagas_ocupadas'] - $other);
        if ($qtd > $available) throw new InvalidArgumentException("Vagas insuficientes. Apenas {$available} disponíveis.");
        if ($modelo === 'grupo_privado' && ($other > 0 || (int)$sessao['vagas_ocupadas'] > 0)) throw new InvalidArgumentException('Esta sessão já tem outras reservas.');
        foreach ($holds as $hold) if (!in_array($hold, $own, true) && $hold['modelo'] === 'grupo_privado') throw new InvalidArgumentException('Esta sessão está reservada para um grupo privado.');
        $dados = isset($input['dados_reserva']) ? json_encode($input['dados_reserva'], JSON_THROW_ON_ERROR | JSON_UNESCAPED_UNICODE) : null;
        if ($own) {
            $keep = $own[0]; $token = (string)$keep['token'];
            $stmt = $conn->prepare("UPDATE reservas_temporarias SET quantidade=?, modelo=?, dados_reserva=?, expira_em=? WHERE id=?");
            $stmt->execute([$qtd,$modelo,$dados,$expires,$keep['id']]);
            // Collapse duplicate active holds left by older checkout versions.
            foreach (array_slice($own,1) as $duplicate) {
                $stmt = $conn->prepare("UPDATE reservas_temporarias SET status='cancelada' WHERE id=?");
                $stmt->execute([$duplicate['id']]);
            }
        } else {
            $token = bin2hex(random_bytes(32));
            $stmt = $conn->prepare("INSERT INTO reservas_temporarias(usuario_id,experiencia_id,sessao_id,quantidade,modelo,token,dados_reserva,expira_em,status) VALUES(?,?,?,?,?,?,?,?,'pendente')");
            $stmt->execute([$uid,(int)$sessao['experiencia_id'],$sid,$qtd,$modelo,$token,$dados,$expires]);
        }
        sincronizarPendentesSessao($conn,(int)$sid);
        $conn->commit();
        return ['success'=>true,'token'=>$token,'expira_em'=>$expires,'segundos_restantes'=>300,'renovada'=>(bool)$own];
    } catch (Throwable $e) { if ($conn->inTransaction()) $conn->rollBack(); throw $e; }
}

function libertarVagasTemporarias(PDO $conn, string $token): array {
    if (!preg_match('/^[a-f0-9]{64}$/D', $token)) throw new InvalidArgumentException('Token inválido.');
    $stmt = $conn->prepare('SELECT sessao_id FROM reservas_temporarias WHERE token=?');
    $stmt->execute([$token]); $sid = $stmt->fetchColumn();
    if (!$sid) return ['success'=>true,'message'=>'Nada a libertar.'];
    $conn->beginTransaction();
    try {
        $stmt = $conn->prepare('SELECT id FROM experiencia_sessoes WHERE id=? FOR UPDATE');
        $stmt->execute([$sid]);
        $stmt = $conn->prepare("UPDATE reservas_temporarias SET status='cancelada' WHERE token=? AND status='pendente'");
        $stmt->execute([$token]);
        $stmt = $conn->prepare("UPDATE reservas_temporarias SET status='expirada' WHERE sessao_id=? AND status='pendente' AND expira_em<=?");
        $stmt->execute([$sid,date('Y-m-d H:i:s')]);
        sincronizarPendentesSessao($conn,(int)$sid);
        $conn->commit();
        return ['success'=>true,'message'=>'Retenção libertada.'];
    } catch (Throwable $e) { if ($conn->inTransaction()) $conn->rollBack(); throw $e; }
}
